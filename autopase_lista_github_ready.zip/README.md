# Autopase de Lista - COBAEM

Aplicación web para que los alumnos registren su asistencia de forma automática, conectada a Firebase y con panel para el docente.

## Características
- Registro con nombre, matrícula y código de clase
- Base de datos en tiempo real (Firestore)
- Filtro por fecha y clase
- Exportación a Excel

Hecho con ❤️ por Edwing